#Copyright ReportLab Europe Ltd. 2000-2004
#see license.txt for license details
#history http://www.reportlab.co.uk/cgi-bin/viewcvs.cgi/public/reportlab/trunk/reportlab/graphics/charts/__init__.py
__version__=''' $Id: __init__.py 3345 2008-12-12 17:55:22Z damian $ '''
__doc__='''Business charts'''
